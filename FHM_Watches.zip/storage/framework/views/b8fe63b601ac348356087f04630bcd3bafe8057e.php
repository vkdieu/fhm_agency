
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\xampp\htdocs\mid\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>