
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\xampp\htdocs\fhm\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>