
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\xampp\htdocs\FHM_agency\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>