
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH D:\project\phanlong\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>