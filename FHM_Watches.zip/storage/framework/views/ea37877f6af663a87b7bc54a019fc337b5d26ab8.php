<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.0.0
  </div>
  <strong>Copyright &copy; 2022 <a href="https://fhmvietnam.vn" target="_blank">FHM Việt Nam</a>.</strong> All rights
  reserved.
</footer>

<div id="loading">
  <div id="overlay" class="overlay"><i class="fa fa-spinner fa-pulse fa-5x fa-fw "></i></div>
</div>
<?php /**PATH C:\xampp\htdocs\FHM_Watches\resources\views/admin/panels/footer.blade.php ENDPATH**/ ?>