



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fhm\resources\views/admin/pages/Cms_video/index.blade.php ENDPATH**/ ?>