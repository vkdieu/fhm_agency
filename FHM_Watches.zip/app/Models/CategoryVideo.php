<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CategoryVideo extends Model
{
    //
    protected $table ='catagory_video';
    
    protected $fillable = ['name','oder',];

}
